# coding=utf-8

from .tokenizer import build_tokenizer
