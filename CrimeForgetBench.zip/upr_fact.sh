#! /bin/bash

# export TRANSFORMERS_CACHE="/mnt/disks/project/transformers-cache"

export CUDA_VISIBLE_DEVICES=3

BASE_DIR="/home/liujianyu/unsupervised-passage-reranking-main/dataset"
DATASET="query2forget"
SPLIT="Df_1000"

MODEL="mt5_large"
HF_MODEL="/home/liujianyu/unsupervised-passage-reranking-main/checkpoints/mt5_qa_epoch30_1000"
# Other possible options are MODEL="t5-v1_1-xl / t5-xl-lm-adapt and HF_MODEL="google/${MODEL}"

RETRIEVER="bm25"
TOPK=1000
EVIDENCE_DATA_PATH="${BASE_DIR}/evidence_schema_data_1000.tsv"

WORLD_SIZE=1
DISTRIBUTED_ARGS="-m torch.distributed.launch --nproc_per_node ${WORLD_SIZE} --nnodes 1 --node_rank 0 --master_addr localhost --master_port 6000"


ARGS=" \
  --num-workers 2 \
  --log-interval 1 \
  --topk-passages ${TOPK} \
  --shard-size 32 \
  --hf-model-name ${HF_MODEL} \
  --use-gpu \
  --report-topk-accuracies 1 5 20 100 \
  --evidence-data-path ${EVIDENCE_DATA_PATH} \
  --retriever-topk-passages-path /home/liujianyu/unsupervised-passage-reranking-main/dataset/bm25_query2forget.json \
  --reranker-output-dir ${BASE_DIR}/retriever-outputs/${RETRIEVER}/reranked/ \
  --merge-shards-and-save \
  --special-suffix ${DATASET}-${SPLIT}-plm-${MODEL}-topk-${TOPK}-prompt "

# `--use-bf16` option provides speed ups and memory savings on Ampere GPUs such as A100 or A6000.
# However, when working with V100 GPUs, this argument should be removed.


# COMMAND="WORLD_SIZE=${WORLD_SIZE} python ${DISTRIBUTED_ARGS} upr_fact.py ${ARGS}"

# 设置debugpy的监听端口，例如 5678
DEBUGPY_PORT=7000

# 构建调试命令
COMMAND="WORLD_SIZE=${WORLD_SIZE} python -m debugpy --listen ${DEBUGPY_PORT} --wait-for-client ${DISTRIBUTED_ARGS} upr_fact.py ${ARGS}"

eval "${COMMAND}"
exit
