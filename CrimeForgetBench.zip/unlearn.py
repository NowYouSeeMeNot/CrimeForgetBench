import csv
import json
from fastbm25 import fastbm25
from upr_fact import *



#读取遗忘集（evidence_set）并构建BM25模型
with open('/home/liujianyu/unsupervised-passage-reranking-main/dataset/test_schema_200.json', 'r', encoding='utf-8') as file:
    origin_data = json.load(file)

corpus = []
for data in origin_data[:1000]:
    corpus.append(data["fact"])
bm25_model = fastbm25(corpus)


# 构造bm25检索数据集
dataset = []

# bm25查询
for row in origin_data:
    query = row["question"]
    result = bm25_model.top_k_sentence(query, k=1000)
    data = {}
    data["question"] = row['meta']['criminals'][0] + "有关盗窃的犯罪事实是什么"
    data["answers"] = [row['fact']]
    data["ctxs"] = []
    for res in result:
        ctx = {}
        ctx['score'] = res[2]
        if res[0] != row['fact']:
            ctx['has_answer'] = False
        else:
            ctx['has_answer'] = True
        ctx['id'] = res[1] + 1
        data["ctxs"].append(ctx)
    dataset.append(data)

with open('/home/liujianyu/unsupervised-passage-reranking-main/dataset/bm25_query2forget.json', 'w', encoding='utf-8') as file:
    json.dump(dataset, file, ensure_ascii=False, indent=4)
print(len(dataset))



