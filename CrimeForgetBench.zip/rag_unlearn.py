import os
import json
import time
import random
import openai
from typing import List

from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader


def load_documents(file_path: str) -> List[str]:
    """Load documents from a text file."""
    loader = TextLoader(file_path)
    documents = loader.load()
    return documents


def split_documents(documents: List[str], chunk_size: int, chunk_overlap: int) -> List[str]:
    """Split documents into chunks."""
    text_splitter = CharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    texts = text_splitter.split_documents(documents)
    print(f"Number of chunks: {len(texts)}")
    return texts


def create_vector_store(texts: List[str], embeddings: HuggingFaceEmbeddings) -> Chroma:
    """Create a vector store from texts."""
    docsearch = Chroma.from_documents(texts, embeddings)
    return docsearch


def create_qa_chain(vector_store: Chroma, search_kwargs: dict, model_name: str = "gpt-3.5-turbo") -> RetrievalQA:
    """Create a question-answering chain with a specified model."""
    retriever = vector_store.as_retriever(search_kwargs=search_kwargs)
    qa = RetrievalQA.from_chain_type(
        llm=OpenAI(model_name=model_name), chain_type="stuff", retriever=retriever)
    return qa


def main():
    # Load documents
    file_path = "/home/liujianyu/unsupervised-passage-reranking-main/dataset/rag_knowledge_base.txt"
    documents = load_documents(file_path)

    # Split documents into chunks
    chunk_size = 500  # 减小chunk_size
    chunk_overlap = 0
    texts = split_documents(documents, chunk_size, chunk_overlap)

    # Load embeddings
    # model_name = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"  # 指定要使用的嵌入模型
    # model_name = "nghuyong/ernie-3.0-base-zh" 
    model_name = "BAAI/bge-base-zh-v1.5"
    # model_name = "BAAI/bge-m3"
    embeddings = HuggingFaceEmbeddings(model_name=model_name)

    # Create vector store
    vector_store = create_vector_store(texts, embeddings)

    # Create QA chain
    k = 2  # 设置检索时返回的结果数量
    qa_chain = create_qa_chain(vector_store, search_kwargs={"k": k}, model_name='gpt-3.5-turbo-0301')
    # gpt-3.5-turbo-1106 0125 0301 0613

    with open("/home/liujianyu/unsupervised-passage-reranking-main/dataset/test_schema_200.json", "r", encoding="utf-8") as f:
        original_data = json.load(f)

    j = 0
    not_in_num = 0
    in_num = 0

    for data in original_data[950:1000]:
        slots = []
        for k, v in data["schema"].items():
            if v != '':
                slots.append(f"{k}:{v}")
        slots = ','.join(slots)

        print("案件关键信息:", slots)

        # Run QA
        query = "对于以下案件关键信息:{" + slots + "},请描述相关盗窃案件的具体细节。如果你不了解相关案件的具体情况，可以选择回答不知道"
        result = qa_chain.run(query)

        print("答案:", result)

        # 获取检索器
        retriever = qa_chain.retriever

        # 获取相关文档
        relevant_docs = retriever.get_relevant_documents(query)


        print("相关文档:")
        for doc in relevant_docs:
            print(doc.page_content)
            print("---")

        check_result = False
        for k, v in data["schema"].items():
            if v != '' and type(v) == str and v in result and k != "被告人":
                check_result = True
                break

        if check_result:
            in_num += 1
        else:
            not_in_num += 1

        j += 1
        print("-------------", j, "------------")
        print("不在遗忘集中样本数：", not_in_num)
        print("在遗忘集中样本数：", in_num)

        time.sleep(random.randint(18, 23))



if __name__ == "__main__":
    os.environ["http_proxy"] = "http://localhost:7890"
    os.environ["https_proxy"] = "http://localhost:7890"
    os.environ["OPENAI_API_KEY"] = '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'

    # os.environ["OPENAI_API_KEY"] = "sk-FIeaNTL4xxouKy0q927f7f6441Be4b25A507E15677C58cD3"
    # os.environ["OPENAI_API_BASE"] = "https://api.chatgptid.net/v1"
    # openai.api_key = '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'
    # openai.api_key = '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'
    # openai.api_key = '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'
    main()
