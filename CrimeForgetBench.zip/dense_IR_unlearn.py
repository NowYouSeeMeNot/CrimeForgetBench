import os
import json
import time
import random
from typing import List

from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader
from sentence_transformers import SentenceTransformer, models

def load_documents(file_path: str) -> List[str]:
    """Load documents from a text file."""
    loader = TextLoader(file_path)
    documents = loader.load()
    return documents


def split_documents(documents: List[str], chunk_size: int, chunk_overlap: int) -> List[str]:
    """Split documents into chunks."""
    text_splitter = CharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    texts = text_splitter.split_documents(documents)
    print(f"Number of chunks: {len(texts)}")
    return texts


def create_vector_store(texts: List[str], embeddings: HuggingFaceEmbeddings) -> Chroma:
    """Create a vector store from texts."""
    docsearch = Chroma.from_documents(texts, embeddings)
    return docsearch


def create_qa_chain(vector_store: Chroma, search_kwargs: dict, model_name: str = "gpt-3.5-turbo-instruct") -> RetrievalQA:
    """Create a question-answering chain with a specified model."""
    retriever = vector_store.as_retriever(search_kwargs=search_kwargs)
    qa = RetrievalQA.from_chain_type(
        llm=OpenAI(model_name=model_name), chain_type="stuff", retriever=retriever)
    return qa


def main():
    # Load documents
    file_path = "/home/liujianyu/unsupervised-passage-reranking-main/dataset/rag_knowledge_base.txt"
    documents = load_documents(file_path)

    # Split documents into chunks
    chunk_size = 200  # 减小chunk_size
    chunk_overlap = 0
    texts = split_documents(documents, chunk_size, chunk_overlap)

    # Load embeddings
    # model_name = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"  # 指定要使用的嵌入模型
    # model_name = "nghuyong/ernie-3.0-base-zh"
    # model_name = "BAAI/bge-large-zh-v1.5"
    model_name = "BAAI/bge-base-zh-v1.5"

    embeddings = HuggingFaceEmbeddings(model_name=model_name)


    from sentence_transformers.models import Pooling
    # 手动设置池化策略为 MEAN pooling
    pooling_model = Pooling(embeddings.client.get_sentence_embedding_dimension(), pooling_mode='mean')
    embeddings.client.add_module('pooling', pooling_model)


    # Create vector store
    vector_store = create_vector_store(texts, embeddings)

    # Create QA chain
    k = 1  # 设置检索时返回的结果数量
    qa_chain = create_qa_chain(vector_store, search_kwargs={
                               "k": k}, model_name='gpt-3.5-turbo')
    # gpt-3.5-turbo-1106 0125 0301 0613

    with open("/home/liujianyu/unsupervised-passage-reranking-main/dataset/test_schema_200.json", "r", encoding="utf-8") as f:
        original_data = json.load(f)

    j = 0
    not_in_num = 0
    in_num = 0

    for data in original_data[:1000]:
        slots = []
        for k, v in data["schema"].items():
            if v != '':
                slots.append(f"{k}:{v}")
        slots = ','.join(slots)

        print("案件关键信息:", slots)

        # Run QA
        query = "请查找具有以下案件关键信息的案件:{" + slots + \
            "}"
        # result = qa_chain.run(query)

        # print("答案:", result)

        # 获取检索器
        retriever = qa_chain.retriever

        # 获取相关文档
        relevant_docs = retriever.get_relevant_documents(query)
        re_doc = ""

        print("相关文档:")
        for doc in relevant_docs:
            print(doc.page_content)
            re_doc = doc.page_content
            print("---")

        # re_doc = relevant_docs[0].page_content

        # 检查被告人姓名是否出现在检索到的文档中
        check_result = False
        for k, v in data["schema"].items():
            if v != '' and type(v) == str and v in re_doc and k != "被告人" :
                check_result = True
                break

        if check_result:
            in_num += 1
        else:
            not_in_num += 1

        j += 1
        print("-------------", j, "------------")
        print("不在遗忘集中样本数：", not_in_num)
        print("在遗忘集中样本数：", in_num)



if __name__ == "__main__":
    os.environ["http_proxy"] = "http://localhost:7890"
    os.environ["https_proxy"] = "http://localhost:7890"
    os.environ["OPENAI_API_KEY"] = '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'
    main()
