import openai
import os
import re
import json
import csv
import time
import random
import logging

# 设置基本配置：日志级别和输出文件
logging.basicConfig(filename='/home/liujianyu/unsupervised-passage-reranking-main/factor_case.log', level=logging.INFO,
                    format='%(asctime)s:%(levelname)s:%(message)s')

# os.environ["http_proxy"] = "http://localhost:7890"
# os.environ["https_proxy"] = "http://localhost:7890"
# openai.api_key = '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'
# openai.api_key = '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'
# openai.api_key = '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'
# openai.api_key = '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'

# openai.api_key = "EMPTY"
# openai.api_base = "http://localhost:8005/v1"


openai.api_key = "sk-jHCx2CXm27lE9F2566Ae0072F6Af4594AcDbF9836c4e8d16"
openai.api_base = "https://api.xty.app/v1"


# 将 JSON 格式字符串转换为 Python 字典
def extract_json(passage):
    pattern = re.compile(r'({.*?(\n}))', re.DOTALL)
    match = pattern.search(passage)
    extracted_content = match.group(1)
    json_content = json.loads(extracted_content)  # 将 JSON 格式字符串转换为 Python 字典
    return json_content


def extract_q_schema(query, select_factor='*'):
    passage = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a data extractor."},
            {"role": "user",
                     "content": str('''
                     请你对以下query抽取关键信息，构建schema
    """
    ''') + query + str('''
    """
    结果请以json形式返回，未涉及的信息则留空:
    {
    "时间":"",
    "地点":"",
    "被告人":"",
    "盗窃物品":"",
    }
    你只需要输出填充好的json，无需其他多余内容
    ''')},
        ]
    )
    # 将 JSON 格式字符串转换为 Python 字典
    schema = extract_json(passage['choices'][0]['message']['content'])
    # time.sleep(random.randint(18, 23))
    slots = []
    for k, v in schema.items():
        if select_factor == '*':
            if v != '':
                slots.append(f"{k}:{v}")
        else:
            if k == select_factor:
                slots.append(f"{k}:{v}")
    slots = ','.join(slots)
    return slots, schema

# 调用LLM搜寻forget_set中是否存在与schama相匹配的案件，返回案件ID（type：json）
def search_case(case, slots):
    passage = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user",
             "content": str('''我将向你提供如下案件信息库：              
    """
    ''') + case + str('''
"""
请你根据以下信息查询上述案件中是否存在相关案件：
###
''') + slots + ('''
###
若存在，则返回相关案件ID，若否，则返回的案件ID为-1。请以json形式返回结果：
{
"案件ID":[]
}
注意：你只需要输出填充好的json，无需其他多余内容
''')},
        ]
    )
    # time.sleep(random.randint(18, 23))
    ID = extract_json(passage['choices'][0]['message']['content'])
    return ID


data_list = []
with open('/home/liujianyu/unsupervised-passage-reranking-main/dataset/evidence_schema_data_1000.tsv', 'r', encoding='utf-8') as file:
    reader = csv.DictReader(file, delimiter='\t')
    for row in reader:
        data_list.append(row)

# 载入案件的schema
with open('/home/liujianyu/unsupervised-passage-reranking-main/dataset/test_schema_200.json', 'r', encoding='utf-8') as files:
    schema_data = json.load(files)
schemas = []
for schema in schema_data:
    schemas.append(schema['schema'])


with open('/home/liujianyu/unsupervised-passage-reranking-main/dataset/retriever-outputs/bm25/reranked/query2forget-Df_1000-plm-mt5_large-topk-1000-Eprompt.json', 'r', encoding='utf-8') as f:
    rerank_res = json.load(f)

not_in_num = 0
in_num = 0
checker_hitnum = 0
used_factor_num = 0
j = 0

# start_time = time.time()

# 定义不同的 k 值
k_values = [1, 2, 3, 4, 5]

# 记录所用factor数
factor_num = {k: 0 for k in k_values}

for data in rerank_res[796:1000]:
    query = data['question']
    check_cases = []
    index = rerank_res.index(data)
    try:
        slots, q_schema = extract_q_schema(query, select_factor='被告人')
    except:
        slots, q_schema = extract_q_schema(query, select_factor='被告人')
    for sample in data['ctxs'][:25]:  # 取前20个检索到的样本作为checker对象
        id = sample['id'] - 1
        source_text = data_list[id]['text']
        check_cases.append(source_text)
    case = ''
    for i in range(len(check_cases)):
        case = case + f"case{i}:" + check_cases[i]
    try:
        ID = search_case(case, slots)
    except:
        ID = search_case(case, slots)
    schema = q_schema
    # schema != ''说明schema补充信息已利用完

    t = 1 #已利用的schema数量
    not_in = False
    empty = 0  # 用于跳出schema都为空的情况

    while len(ID['案件ID']) != 1 and (schema['盗窃物品'] == '' or schema['被告人'] == '' or schema['时间'] == '' or schema['地点'] == '') and t < 3 and empty < 3 and not_in == False:
        for k, v in schema.items():
            if schema[k] == '':
                if schemas[index][k] == '':
                    empty += 1
                    continue
                else:
                    used_factor_num += 1
                    add_schema = schemas[index][k]
                    slots = slots + ',' + f'{k}:{add_schema}'
                    schema[k] = add_schema
                    t = t + 1

                    # 更新case
                    # case = ''
                    # for i in range(len(ID['案件ID'])):
                    #     case_id = str(ID['案件ID'][i]).replace('case', '')
                    #     case = case + f"case{case_id}:" + \
                    #         check_cases[int(case_id)]

                    try:
                        ID = search_case(case, slots)
                    except:
                        ID = search_case(case, slots)
                    # 不存在相关案件时，checker可能返回的list为空
                    # if len(ID['案件ID']) == 0:
                    #     not_in = True
                    #     break

                    if len(ID['案件ID']) == 1:
                        break
                        # 对于非遗忘集，checker的正确输出应该为-1，即无相关案件
                        # check_ID = int(str(ID['案件ID'][0]).replace('case', ''))
                        # if check_ID == -1:
                        #     break

    factor_num[t] += 1

    if len(ID['案件ID']) == 0:
        not_in_num += 1
    elif len(ID['案件ID']) > 1:  # checker使用schema之后认为有多个符合的案件，则认为在遗忘集中
        in_num += 1
    else:
        check_ID = int(str(ID['案件ID'][0]).replace('case', ''))
        if check_ID == -1:
            # print("不在遗忘集中")
            not_in_num += 1
        elif check_ID != -1:
            # print("在遗忘集中")
            in_num += 1
            for item in data_list:
                if int(item['id']) == index + 1:
                    if check_cases[check_ID] == item['text']:
                        checker_hitnum += 1
                        if t == 4:
                            logging.info(
                                f"factor num: {t}   case: {item['text']}")
                            logging.info(
                                "**************************************************************")
                        elif t == 3:
                            logging.info(
                                f"factor num: {t}   case: {item['text']}")
                            logging.info(
                                "**************************************************************")
                        break

    j += 1
    print("-------------", j, "------------")
    print("不在遗忘集中样本数：", not_in_num)
    print("在遗忘集中样本数：", in_num)
    print("LLMchecker命中样本数：", checker_hitnum)
    print("所需factor数：", used_factor_num)
    print(factor_num)


    # t = 1
    # while len(ID['案件ID']) != 1 and (schema['盗窃物品'] == '' or schema['被告人'] == '' or schema['时间'] == '' or schema['地点'] == '') and t < 3:
    #     for k, v in schema.items():
    #         if schema[k] == '':
    #             used_factor_num += 1
    #             if schemas[index][k] == '':
    #                 continue
    #             else:
    #                 add_schema = schemas[index][k]
    #                 slots = slots + ',' + f'{k}:{add_schema}'
    #                 schema[k] = add_schema
    #                 t = t + 1
    #                 try:
    #                     ID = search_case(case, slots)
    #                 except:
    #                     ID = search_case(case, slots)
    #                 if len(ID['案件ID']) == 1:
    #                     break
            
    # factor_num[t] += 1

    # if len(ID['案件ID']) != 1:
    #    in_num += 1
    # else:
    #     check_ID = int(str(ID['案件ID'][0]).replace('case', ''))
    #     if check_ID == -1:
    #         # print("不在遗忘集中")
    #         not_in_num += 1
    #     elif check_ID != -1:
    #         # print("在遗忘集中")
    #         in_num += 1
    #         for item in data_list:
    #             if int(item['id']) == index + 1:
    #                 if check_cases[check_ID] == item['text']:
    #                     checker_hitnum += 1
    #                     if t == 3:
    #                         logging.info(f"factor num: {t}   case: {item['text']}")
    #                     elif t == 2:
    #                         logging.info(f"factor num: {t}   case: {item['text']}")
    #                     break

    # j += 1
    # print("-------------", j, "------------")
    # print("不在遗忘集中样本数：", not_in_num)
    # print("在遗忘集中样本数：", in_num)
    # print("LLMchecker命中样本数：", checker_hitnum)
    # print("所需factor数：", used_factor_num)
    # print(factor_num)
