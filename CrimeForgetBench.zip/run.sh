export CUDA_VISIBLE_DEVICES=0
DISTRIBUTED_ARGS="-m torch.distributed.launch --nproc_per_node 1 --nnodes 1 --node_rank 0 --master_addr localhost --master_port 6000"

python ${DISTRIBUTED_ARGS} upr.py \ 
  --num-workers 2 \
  --log-interval 1 \
  --topk-passages 1000 \
  --hf-model-name "/home/user/unsupervised-passage-reranking-main/checkpoints/mt5_qa_epoch30_1000" \
  --use-gpu \
  --use-bf16 \
  --report-topk-accuracies 1 5 20 100 \
  --evidence-data-path "/home/user/unsupervised-passage-reranking-main/dataset/source_data_1000.tsv" \
  --retriever-topk-passages-path "/home/user/unsupervised-passage-reranking-main/dataset/bm25_retrieval_1000.json"