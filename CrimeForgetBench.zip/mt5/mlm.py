import json
import torch
from transformers import MT5ForConditionalGeneration, MT5Tokenizer
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from transformers import get_linear_schedule_with_warmup
import random
import numpy as np
import os

# 确保结果可复现


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


set_seed(42)

# 数据准备


class MyDataset(Dataset):
    def __init__(self, texts, tokenizer, max_len=512):
        self.texts = texts
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        inputs = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=self.max_len,
            padding="max_length",
            return_tensors="pt",
            truncation=True
        )

        # 输入ids和mask
        input_ids = inputs["input_ids"].flatten()
        attention_mask = inputs["attention_mask"].flatten()

        # 随机掩码部分token
        input_ids, labels = self.random_word_masking(input_ids)

        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": labels
        }

    def random_word_masking(self, input_ids):
        labels = input_ids.clone()
        # 定义要掩码的概率
        probability = 0.15

        # 对于每个token，随机决定是否替换为掩码
        rand = torch.rand(input_ids.shape)
        mask_arr = (rand < probability) * \
            (input_ids != self.tokenizer.pad_token_id)

        # 不掩码special tokens
        selection = [
            self.tokenizer.convert_ids_to_tokens(int(input_id))
            for input_id in input_ids
        ]
        for i in range(len(selection)):
            if selection[i] in self.tokenizer.all_special_tokens:
                mask_arr[i] = False

        labels[~mask_arr] = -100
        input_ids[mask_arr] = self.tokenizer.convert_tokens_to_ids(
            self.tokenizer.mask_token)
        return input_ids, labels


with open('/home/liujianyu/unsupervised-passage-reranking-main/dataset/test_subset_200.json', 'r', encoding='utf-8') as f:
    origin_data = json.load(f)


texts = []
for data in origin_data[:1000]:
    texts.append(data['fact'])


# 设置模型和分词器
model_name = "/data1/sharedllms/mt5/large"
tokenizer = MT5Tokenizer.from_pretrained(model_name)
model = MT5ForConditionalGeneration.from_pretrained(model_name)

# 设置mask token
if tokenizer.mask_token is None:
    tokenizer.add_special_tokens({'mask_token': '<extra_id_0>'})

epoch = 30

# 数据加载器
dataset = MyDataset(texts, tokenizer, max_len=256)
loader = DataLoader(dataset, batch_size=4, shuffle=True)

# 优化器和调度器
optimizer = AdamW(model.parameters(), lr=5e-5)
total_steps = len(loader) * epoch  # 假设训练5个epoch
# 设置预热步骤为总步骤数的 10%
num_warmup_steps = int(0.1 * total_steps)
scheduler = get_linear_schedule_with_warmup(
    optimizer, num_warmup_steps=num_warmup_steps, num_training_steps=total_steps)

# 训练模型
device = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")
model.to(device)


for epoch in range(epoch):
    model.train()
    total_loss = 0
    for batch in loader:
        optimizer.zero_grad()

        input_ids = batch["input_ids"].to(device)
        attention_mask = batch["attention_mask"].to(device)
        labels = batch["labels"].to(device)

        outputs = model(input_ids=input_ids,
                        attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        total_loss += loss.item()

        loss.backward()
        optimizer.step()
        scheduler.step()

    print(f"Epoch {epoch + 1}, Loss: {total_loss / len(loader)}")

# 保存模型
model_save_path = "/home/liujianyu/unsupervised-passage-reranking-main/checkpoints/mt5_epoch20_1000/"
tokenizer_save_path = "/home/liujianyu/unsupervised-passage-reranking-main/checkpoints/mt5_epoch20_1000/"
os.makedirs(model_save_path, exist_ok=True)
model.save_pretrained(model_save_path)
tokenizer.save_pretrained(tokenizer_save_path)
