import torch
from torch.utils.data import Dataset, DataLoader
from transformers import MT5ForConditionalGeneration, MT5Tokenizer
from torch.optim import AdamW
from transformers import get_linear_schedule_with_warmup
import random
import numpy as np
import json
import os

# 确保实验可重复


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(42)

# 加载数据集
with open('/home/liujianyu/unsupervised-passage-reranking-main/dataset/test_subset_200.json', 'r', encoding='utf-8') as f:
    origin_data = json.load(f)

questions = []
answers = []
for data in origin_data[:1000]:
    questions.append(data['fact'])
    answers.append(data["question"])



# 数据集类
class QADataset(Dataset):
    def __init__(self, questions, answers, tokenizer, max_length=256):
        self.questions = questions
        self.answers = answers
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.questions)

    def __getitem__(self, idx):
        source_text = self.questions[idx]
        target_text = self.answers[idx]

        source = self.tokenizer.encode_plus(
            source_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,                                                                                           
            return_tensors="pt"
        )

        target = self.tokenizer.encode_plus(
            target_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors="pt"
        )

        return source, target


# 加载模型和分词器
tokenizer = MT5Tokenizer.from_pretrained('/data1/sharedllms/mt5/large')
model = MT5ForConditionalGeneration.from_pretrained(
    '/data1/sharedllms/mt5/large')

# 准备数据加载器
dataset = QADataset(questions, answers, tokenizer)
loader = DataLoader(dataset, batch_size=4, shuffle=True)

# 设置设备
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

# 微调模型
num_epochs = 35

# 设置优化器和学习率调度器
optimizer = AdamW(model.parameters(), lr=5e-5)
total_steps = len(loader) * num_epochs
# 设置预热步骤为总步骤数的 10%
num_warmup_steps = int(0.1 * total_steps)
scheduler = get_linear_schedule_with_warmup(
    optimizer, num_warmup_steps=num_warmup_steps, num_training_steps=total_steps)


model.train()

for epoch in range(num_epochs):
    total_loss = 0
    for batch in loader:
        source, target = batch
        input_ids = source['input_ids'].squeeze(1).to(device)
        attention_mask = source['attention_mask'].squeeze(1).to(device)
        labels = target['input_ids'].squeeze(1).to(device)

        outputs = model(input_ids=input_ids,
                        attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        total_loss += loss.item()
        loss.backward()

        optimizer.step()
        scheduler.step()
        optimizer.zero_grad()
    print(f"Epoch {epoch + 1}, Loss: {total_loss / len(loader)}")

# 保存模型
model_save_path = "/home/liujianyu/unsupervised-passage-reranking-main/checkpoints/mt5_qa_epoch35_1000/"
tokenizer_save_path = "/home/liujianyu/unsupervised-passage-reranking-main/checkpoints/mt5_qa_epoch35_1000/"
os.makedirs(model_save_path, exist_ok=True)
model.save_pretrained(model_save_path)
tokenizer.save_pretrained(tokenizer_save_path)

